import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, CheckCircle, AlertTriangle } from 'lucide-react';

export default function BudgetBar({ budget }: { budget: any }) {
  if (!budget) return null;

  // Calculate percentage used
  const totalSpent = budget.grand_total - budget.under_budget_by;
  const percentageUsed = (totalSpent / budget.grand_total) * 100;
  
  // Determine status
  const getStatusInfo = () => {
    if (budget.under_budget_by > 0) {
      return {
        icon: CheckCircle,
        text: "Under Budget",
        color: "text-green-400",
        bgColor: "bg-green-500/20"
      };
    } else if (budget.under_budget_by === 0) {
      return {
        icon: AlertTriangle,
        text: "At Budget Limit",
        color: "text-yellow-400",
        bgColor: "bg-yellow-500/20"
      };
    } else {
      return {
        icon: AlertTriangle,
        text: "Over Budget",
        color: "text-red-400",
        bgColor: "bg-red-500/20"
      };
    }
  };

  const status = getStatusInfo();
  const StatusIcon = status.icon;

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/50 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/20 rounded-lg">
            <DollarSign className="w-6 h-6 text-emerald-400" />
          </div>
          <h3 className="text-xl font-semibold text-white">Budget Breakdown</h3>
        </div>
        
        <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${status.bgColor}`}>
          <StatusIcon className={`w-4 h-4 ${status.color}`} />
          <span className={`text-sm font-medium ${status.color}`}>
            {status.text}
          </span>
        </div>
      </div>

      {/* Budget Categories */}
      <div className="space-y-3 mb-6">
        {Object.entries(budget.totals).map(([category, amount]) => {
          const categoryPercentage = ((amount as number) / budget.grand_total) * 100;
          
          return (
            <div key={category} className="bg-gray-900/30 rounded-lg p-4 border border-gray-700/30">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300 font-medium capitalize">
                  {category.replace(/_/g, ' ')}
                </span>
                <span className="text-white font-semibold">
                  ₹{(amount as number).toLocaleString()}
                </span>
              </div>
              
              {/* Category progress bar */}
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-400 to-emerald-400 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(categoryPercentage, 100)}%` }}
                />
              </div>
              
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs text-gray-500">
                  {categoryPercentage.toFixed(1)}% of total
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Grand Total Section */}
      <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 rounded-xl p-4 border border-gray-600/30">
        <div className="flex justify-between items-center mb-3">
          <span className="text-lg font-semibold text-gray-300">Grand Total</span>
          <span className="text-2xl font-bold text-white">
            ₹{budget.grand_total.toLocaleString()}
          </span>
        </div>

        {/* Overall progress bar */}
        <div className="w-full bg-gray-700 rounded-full h-3 mb-3">
          <div
            className={`h-3 rounded-full transition-all duration-700 ${
              percentageUsed <= 80 
                ? 'bg-gradient-to-r from-green-400 to-emerald-500' 
                : percentageUsed <= 95
                ? 'bg-gradient-to-r from-yellow-400 to-orange-500'
                : 'bg-gradient-to-r from-orange-500 to-red-500'
            }`}
            style={{ width: `${Math.min(percentageUsed, 100)}%` }}
          />
        </div>

        {/* Remaining Budget */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            {budget.under_budget_by > 0 ? (
              <TrendingDown className="w-4 h-4 text-green-400" />
            ) : (
              <TrendingUp className="w-4 h-4 text-red-400" />
            )}
            <span className="text-sm text-gray-400">
              {budget.under_budget_by > 0 ? 'Remaining' : 'Over Budget'}
            </span>
          </div>
          
          <span className={`font-semibold ${
            budget.under_budget_by > 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            ₹{Math.abs(budget.under_budget_by).toLocaleString()}
          </span>
        </div>
      </div>

      {/* Budget Insights */}
      <div className="mt-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
        <div className="flex items-start gap-2">
          <div className="p-1 bg-blue-500/20 rounded">
            <TrendingUp className="w-3 h-3 text-blue-400" />
          </div>
          <div>
            <p className="text-xs text-blue-300 font-medium mb-1">Budget Insight</p>
            <p className="text-xs text-gray-400">
              {budget.under_budget_by > 0 
                ? `You're saving ₹${budget.under_budget_by.toLocaleString()}! Consider upgrading accommodations or adding activities.`
                : budget.under_budget_by === 0
                ? "Perfect! You're right on budget."
                : `You're ₹${Math.abs(budget.under_budget_by).toLocaleString()} over budget. Consider adjusting your plans.`
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
