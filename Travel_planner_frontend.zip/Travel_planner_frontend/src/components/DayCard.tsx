import React from 'react';
import { Calendar, Clock, MapPin, DollarSign, Sun, Moon, Coffee, Camera } from 'lucide-react';

export default function DayCard({ day }: { day: any }) {
  if (!day) return null;

  // Get day of week from date
  const dayOfWeek = new Date(day.date).toLocaleDateString('en-US', { weekday: 'long' });
  const formattedDate = new Date(day.date).toLocaleDateString('en-US', { 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  });

  // Function to get icon based on activity type
  const getActivityIcon = (activity: string) => {
    const activityLower = activity.toLowerCase();
    if (activityLower.includes('breakfast') || activityLower.includes('lunch') || activityLower.includes('dinner') || activityLower.includes('food')) {
      return Coffee;
    } else if (activityLower.includes('sightseeing') || activityLower.includes('visit') || activityLower.includes('tour')) {
      return Camera;
    } else if (activityLower.includes('morning') || activityLower.includes('sunrise')) {
      return Sun;
    } else if (activityLower.includes('evening') || activityLower.includes('night') || activityLower.includes('sunset')) {
      return Moon;
    }
    return MapPin;
  };

  // Function to get time-based styling
  const getTimeColor = (time: string) => {
    const hour = parseInt(time.split(':')[0]);
    if (hour < 12) return 'text-orange-400 bg-orange-500/20';
    else if (hour < 17) return 'text-blue-400 bg-blue-500/20';
    else return 'text-purple-400 bg-purple-500/20';
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-xl overflow-hidden mb-6 hover:border-gray-600/50 transition-all duration-300">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 p-6 border-b border-gray-700/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-500/20 rounded-xl">
              <Calendar className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{dayOfWeek}</h3>
              <p className="text-blue-300 font-medium">{formattedDate}</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center gap-2 text-emerald-400">
              <DollarSign className="w-4 h-4" />
              <span className="text-sm font-medium">Daily Total</span>
            </div>
            <p className="text-2xl font-bold text-white">
              ₹{day.day_cost_total?.toLocaleString() || 0}
            </p>
          </div>
        </div>
      </div>

      {/* Activities Timeline */}
      <div className="p-6">
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-4 bottom-4 w-0.5 bg-gradient-to-b from-blue-500/50 via-purple-500/50 to-emerald-500/50" />
          
          <div className="space-y-4">
            {day.plan?.map((item: any, idx: number) => {
              const ActivityIcon = getActivityIcon(item.activity);
              const timeColorClass = getTimeColor(item.time);
              
              return (
                <div key={idx} className="relative flex items-start gap-4 group">
                  {/* Timeline dot */}
                  <div className="relative z-10 p-2 bg-gray-800 rounded-full border-2 border-blue-500/30 group-hover:border-blue-500/60 transition-colors">
                    <ActivityIcon className="w-4 h-4 text-blue-400" />
                  </div>
                  
                  {/* Activity Card */}
                  <div className="flex-1 bg-gray-900/30 rounded-xl p-4 border border-gray-700/30 group-hover:border-gray-600/50 group-hover:bg-gray-900/50 transition-all duration-200">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${timeColorClass}`}>
                            {item.time}
                          </span>
                          <div className="h-1 w-1 bg-gray-600 rounded-full" />
                          <span className="text-xs text-gray-400 uppercase tracking-wide">
                            Activity {idx + 1}
                          </span>
                        </div>
                        
                        <h4 className="text-lg font-semibold text-white mb-2 group-hover:text-blue-300 transition-colors">
                          {item.activity}
                        </h4>
                        
                        {item.description && (
                          <p className="text-sm text-gray-400 mb-2">
                            {item.description}
                          </p>
                        )}
                        
                        {item.location && (
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <MapPin className="w-3 h-3" />
                            <span>{item.location}</span>
                          </div>
                        )}
                      </div>
                      
                      {/* Cost */}
                      <div className="text-right">
                        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2">
                          <div className="flex items-center gap-1 text-emerald-400">
                            <DollarSign className="w-3 h-3" />
                            <span className="text-xs font-medium">Cost</span>
                          </div>
                          <p className="text-lg font-bold text-white">
                            ₹{item.cost_inr?.toLocaleString() || 0}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            }) || (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No activities planned for this day</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer Summary */}
      <div className="bg-gray-900/30 px-6 py-4 border-t border-gray-700/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm text-gray-400">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{day.plan?.length || 0} activities planned</span>
            </div>
            {day.plan && day.plan.length > 0 && (
              <div className="flex items-center gap-1">
                <span>•</span>
                <span>
                  {day.plan[0].time} - {day.plan[day.plan.length - 1].time}
                </span>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">Avg per activity:</span>
            <span className="font-semibold text-emerald-400">
              ₹{day.plan?.length ? Math.round(day.day_cost_total / day.plan.length).toLocaleString() : 0}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
