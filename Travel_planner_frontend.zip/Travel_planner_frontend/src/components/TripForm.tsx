import { useMemo, useState } from "react";
import type { TripFormPayload } from "../api/client"; // <- use the shared type

export default function TripForm({ onSubmit }: { onSubmit: (p: TripFormPayload) => void }) {
  const [city, setCity] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [people, setPeople] = useState<number>(2);
  const [budget, setBudget] = useState<number>(25000);

  // keep end-date min in sync with start date
  const endMin = useMemo(() => (start ? start : undefined), [start]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanCity = city.trim();
    if (!cleanCity) return alert("Please enter a destination city.");
    if (!start || !end) return alert("Please select start and end dates.");
    if (new Date(end) < new Date(start)) return alert("End date cannot be before start date.");

    const safePeople = Math.max(1, Math.floor(Number.isFinite(people) ? people : 1));
    const safeBudget = Math.max(0, Math.floor(Number.isFinite(budget) ? budget : 0));

    const payload: TripFormPayload = {
      city: cleanCity,
      start_date: start,
      end_date: end,
      people: safePeople,
      budget_total_inr: safeBudget,
      // keep preferences minimal and city-agnostic (no Jaipur defaults)
      preferences: {
        stay: { min_rating: 3.8, areas: [], ac_required: true, refundable: true },
        food: { veg_only: true, meals_per_day: 2 },
        pace: "relaxed",
        must_visit: [],
        avoid: []
      }
    };

    onSubmit(payload);
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{ display: "flex", flexDirection: "column", gap: "0.75rem", maxWidth: 360 }}
    >
      <input
        value={city}
        onChange={(e) => setCity(e.target.value)}
        placeholder="Destination city (e.g., Indore)"
        required
      />

      <label>
        Start Date
        <input type="date" value={start} onChange={(e) => setStart(e.target.value)} required />
      </label>

      <label>
        End Date
        <input
          type="date"
          value={end}
          min={endMin}
          onChange={(e) => setEnd(e.target.value)}
          required
        />
      </label>

      <label>
        People
        <input
          type="number"
          min={1}
          value={people}
          onChange={(e) => setPeople(Number(e.target.value) || 1)}
          required
        />
      </label>

      <label>
        Budget (₹)
        <input
          type="number"
          min={0}
          step={500}
          value={budget}
          onChange={(e) => setBudget(Number(e.target.value) || 0)}
          required
        />
      </label>

      <button type="submit">Plan Trip</button>
    </form>
  );
}
