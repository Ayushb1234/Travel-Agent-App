// src/components/MapView.tsx
import React, { useMemo, useState } from "react";
import {
  Map as MapIcon,
  MapPin,
  Star,
  Wifi,
  Car,
  Coffee,
  Utensils,
  Dumbbell,
  Navigation,
  Filter,
} from "lucide-react";

// ===== Leaflet (map will render only when coords exist) =====
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});


// ----------------- Types -----------------
export interface Hotel {
  id: string | number;
  name: string;
  price?: { amount: number };
  rating: number; // 0..5
  location?: string;
  description?: string;
  amenities?: string[];
  distance?: string;
  phone?: string;
  email?: string;
  /** NEW (optional) — provide when you have coords from backend */
  lat?: number;
  lng?: number;
}

type SortKey = "rating" | "price" | "name";

// ----------------- Subcomponents -----------------
const StarRating: React.FC<{ rating: number; className?: string }> = ({
  rating,
  className = "",
}) => (
  <div className={`flex items-center gap-1 ${className}`}>
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={`w-4 h-4 ${
          star <= Math.floor(rating)
            ? "text-yellow-400 fill-current"
            : star <= rating
            ? "text-yellow-400 fill-current opacity-50"
            : "text-gray-500"
        }`}
      />
    ))}
    <span className="text-sm text-gray-300 ml-1">({rating})</span>
  </div>
);

// ----------------- Utilities -----------------
const getAmenityIcon = (amenity: string) => {
  const a = amenity.toLowerCase();
  if (a.includes("wifi") || a.includes("internet")) return Wifi;
  if (a.includes("parking") || a.includes("car")) return Car;
  if (a.includes("breakfast") || a.includes("coffee") || a.includes("caf\u00E9"))
    return Coffee;
  if (a.includes("restaurant") || a.includes("dining")) return Utensils;
  if (a.includes("gym") || a.includes("fitness")) return Dumbbell;
  return MapPin;
};

// ----------------- Main -----------------
export default function MapView({ hotels }: { hotels: Hotel[] }) {
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [filterRating, setFilterRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<SortKey>("rating");

  if (!hotels?.length) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 shadow-xl text-center">
        <MapIcon className="w-16 h-16 text-gray-500 mx-auto mb-4 opacity-50" />
        <h3 className="text-xl font-semibold text-gray-400 mb-2">
          No Hotels Available
        </h3>
        <p className="text-gray-500">
          Hotel options will appear here once your trip is planned.
        </p>
      </div>
    );
  }

  const filteredHotels = useMemo(() => {
    const list = hotels.filter(
      (h) =>
        !filterRating ||
        (typeof h.rating === "number" && h.rating >= filterRating)
    );
    return list.sort((a, b) => {
      switch (sortBy) {
        case "price": {
          const ap = a.price?.amount ?? Number.POSITIVE_INFINITY;
          const bp = b.price?.amount ?? Number.POSITIVE_INFINITY;
          return ap - bp;
        }
        case "rating":
          return (b.rating ?? 0) - (a.rating ?? 0);
        case "name":
          return (a.name || "").localeCompare(b.name || "");
        default:
          return 0;
      }
    });
  }, [hotels, filterRating, sortBy]);

  // ===== Map config =====
  const withCoords = filteredHotels.filter(
    (h) => typeof h.lat === "number" && typeof h.lng === "number"
  );
  const hasMapData = withCoords.length > 0;

  // center: first hotel with coords; else fallback to India centroid
  const center: [number, number] = hasMapData
    ? [withCoords[0].lat as number, withCoords[0].lng as number]
    : [20.5937, 78.9629];

  // Map tiles: MapTiler if key present, else OSM
  const maptilerKey = import.meta.env.VITE_MAPTILER_KEY as
    | string
    | undefined;
  const tileUrl = maptilerKey
    ? `https://api.maptiler.com/maps/streets-v2/256/{z}/{x}/{y}.png?key=${maptilerKey}`
    : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  const tileAttribution = maptilerKey
    ? '&copy; <a href="https://www.maptiler.com/copyright/">MapTiler</a> &copy; OpenStreetMap contributors'
    : '&copy; OpenStreetMap contributors';

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-gray-700/50 shadow-xl overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600/20 to-blue-600/20 p-6 border-b border-gray-700/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 rounded-lg">
              <MapIcon className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">
                Hotel Options & Map
              </h3>
              <p className="text-emerald-300 text-sm">
                {hotels.length} hotels found
              </p>
            </div>
          </div>
        </div>

        {/* Filters and Sort */}
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={filterRating}
              onChange={(e) => setFilterRating(Number(e.target.value))}
              className="bg-gray-700/50 border border-gray-600 rounded-lg px-3 py-1 text-sm text-white focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            >
              <option value={0}>All Ratings</option>
              <option value={3}>3+ Stars</option>
              <option value={4}>4+ Stars</option>
              <option value={4.5}>4.5+ Stars</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortKey)}
              className="bg-gray-700/50 border border-gray-600 rounded-lg px-3 py-1 text-sm text-white focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            >
              <option value="rating">Rating</option>
              <option value="price">Price</option>
              <option value="name">Name</option>
            </select>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="relative">
        {hasMapData ? (
        <MapContainer
  center={[19.076, 72.8777]} // Mumbai fallback
  zoom={12}
  style={{ height: "250px", width: "100%" }}
>
  <TileLayer
    url={`https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${import.meta.env.VITE_MAPTILER_KEY}`}
    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> contributors'
  />
  {hotels.map((h, i) => (
    <Marker key={i} position={[19.076 + i*0.01, 72.8777 + i*0.01]}>
      <Popup>{h.name}</Popup>
    </Marker>
  ))}
</MapContainer>

        ) : (
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 h-64 flex items-center justify-center border-b border-gray-700/30">
            <div className="text-center">
              <div className="relative">
                <div className="absolute inset-0 bg-emerald-500/20 rounded-full animate-ping" />
                <Navigation className="w-12 h-12 text-emerald-400 relative z-10" />
              </div>
              <p className="text-gray-400 mt-2">Interactive Map</p>
              <p className="text-gray-500 text-sm">
                Add <code>lat</code>/<code>lng</code> in hotel data to show markers
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Hotel Grid */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredHotels.map((hotel) => {
            const isSelected = selectedHotel?.id === hotel.id;
            const nightly = hotel.price?.amount ?? 0;

            return (
              <div
                key={hotel.id}
                className={`bg-gray-900/30 rounded-xl p-4 border transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? "border-emerald-500/50 bg-emerald-900/20"
                    : "border-gray-700/30 hover:border-gray-600/50 hover:bg-gray-900/50"
                }`}
                onClick={() => setSelectedHotel(isSelected ? null : hotel)}
              >
                {/* Hotel Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="font-semibold text-white text-lg mb-1">
                      {hotel.name}
                    </h4>
                    <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                      <MapPin className="w-3 h-3" />
                      <span>{hotel.location || "City Center"}</span>
                    </div>
                    <StarRating rating={hotel.rating ?? 0} />
                  </div>

                  <div className="text-right">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2">
                      <p className="text-xs text-emerald-400 font-medium">
                        Per Night
                      </p>
                      <p className="text-lg font-bold text-white">
                        ₹{nightly.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Amenities */}
                {hotel.amenities?.length ? (
                  <div className="flex flex-wrap gap-2 mb-3">
                    {hotel.amenities.slice(0, 4).map((amenity, idx) => {
                      const AmenityIcon = getAmenityIcon(amenity);
                      return (
                        <div
                          key={`${amenity}-${idx}`}
                          className="flex items-center gap-1 bg-gray-700/30 px-2 py-1 rounded-full"
                        >
                          <AmenityIcon className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-400">{amenity}</span>
                        </div>
                      );
                    })}
                    {hotel.amenities.length > 4 && (
                      <span className="text-xs text-gray-500">
                        +{hotel.amenities.length - 4} more
                      </span>
                    )}
                  </div>
                ) : null}

                {/* Description */}
                {hotel.description && (
                  <p className="text-sm text-gray-400 mb-3 line-clamp-2">
                    {hotel.description}
                  </p>
                )}

                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-gray-700/30">
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>₹{(nightly * 7).toLocaleString()}/week</span>
                    {hotel.distance && (
                      <span className="flex items-center gap-1">
                        <Navigation className="w-3 h-3" />
                        {hotel.distance}
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    className="text-emerald-400 hover:text-emerald-300 text-sm font-medium transition-colors"
                  >
                    {isSelected ? "Hide Details" : "View Details"}
                  </button>
                </div>

                {/* Expanded Details */}
                {isSelected && (
                  <div className="mt-4 pt-4 border-top border-gray-700/30">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <h5 className="text-sm font-medium text-white mb-2">
                          Contact
                        </h5>
                        <p className="text-sm text-gray-400">
                          {hotel.phone || ""}
                        </p>
                        <p className="text-sm text-gray-400">
                          {hotel.email || ""}
                        </p>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-white mb-2">
                          Policies
                        </h5>
                        <p className="text-sm text-gray-400">Check-in: 3:00 PM</p>
                        <p className="text-sm text-gray-400">Check-out: 11:00 AM</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      className="w-full mt-4 bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-all duration-200"
                    >
                      Select This Hotel
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredHotels.length === 0 && (
          <div className="text-center py-8">
            <Filter className="w-12 h-12 text-gray-500 mx-auto mb-3 opacity-50" />
            <p className="text-gray-400">No hotels match your filters</p>
            <button
              type="button"
              onClick={() => {
                setFilterRating(0);
                setSortBy("rating");
              }}
              className="text-emerald-400 hover:text-emerald-300 text-sm mt-2 transition-colors"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
