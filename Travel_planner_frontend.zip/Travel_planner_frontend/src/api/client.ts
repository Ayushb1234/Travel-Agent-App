// src/api/client.ts
export type TripFormPayload = {
  city: string;
  start_date: string; // ISO yyyy-mm-dd
  end_date: string;   // ISO yyyy-mm-dd
  people: number;
  budget_total_inr: number;
  preferences?: any;
};

export type Budget = {
  totals: Record<string, number>;
  grand_total: number;
  under_budget_by: number;
};

export type Hotel = {
  id: string | number;
  name: string;
  price?: { amount: number; unit?: string };
  rating?: number;
  reviews_count?: number;
  amenities?: string[];
  area?: string;
  url?: string | null;
};

export type PlanItem = { time: string; activity: string; cost_inr: number; description?: string; location?: string; };
export type Day = { date: string; plan?: PlanItem[]; day_cost_total?: number };

export type PlanResponse = {
  budget: Budget;
  hotel_choices: Hotel[];
  days: Day[];
};

const API = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export async function planTrip(payload: TripFormPayload): Promise<PlanResponse> {
  const res = await fetch(`${API}/plan`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`Plan failed (${res.status}): ${txt}`);
  }
  return res.json();
}
