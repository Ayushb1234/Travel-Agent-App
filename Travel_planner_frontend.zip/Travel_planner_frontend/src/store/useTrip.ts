// src/store/useTrip.ts
import { useState } from "react";
import type { PlanResponse, TripFormPayload } from "../api/client";

export function useTrip() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PlanResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function submitTrip(payload: TripFormPayload, apiFn: (p: TripFormPayload) => Promise<PlanResponse>) {
    try {
      setLoading(true);
      setError(null);
      setResult(null);
      const data = await apiFn(payload);
      setResult(data);
    } catch (e: any) {
      setError(e?.message ?? "Unknown error");
    } finally {
      setLoading(false);
    }
  }

  return { loading, result, error, submitTrip };
}
