// src/pages/Planner.tsx
import React from "react";
import TripForm from "../components/TripForm";
import BudgetBar from "../components/BudgetBar";
import DayCard from "../components/DayCard";
import MapView, { type Hotel as UIHotel } from "../components/MapView";
import { useTrip } from "../store/useTrip";
import { planTrip } from "../api/client";
import { Loader2, AlertCircle } from "lucide-react";

// --- Types that match backend response ---
type Budget = {
  totals: Record<string, number>;
  grand_total: number;
  under_budget_by: number;
};

// Simplified API hotel (mock/OSM-based)
type ApiHotel = {
  id: string | number;
  name: string;
  price?: { amount?: number; unit?: string | null };
  rating?: number | null;
  reviews_count?: number | null;
  amenities?: string[] | null;
  area?: string | null;
  url?: string | null; // optional, keep if backend sets it
};

type PlanItem = {
  time: string;
  activity: string;
  description?: string;
  location?: string;
  cost_inr: number;
};

type Day = {
  date: string;
  plan: PlanItem[];
  day_cost_total: number;
};

type PlanResponse = {
  budget: Budget;
  hotel_choices: ApiHotel[];
  days: Day[];
};

// --- Normalizer: API -> UI type for MapView ---
function normalizeHotels(api: ApiHotel[] | undefined | null): UIHotel[] {
  if (!api?.length) return [];
  return api.map((h, i) => ({
    id: (h.id ?? i) as string | number,
    name: h.name ?? `Hotel ${i + 1}`,
    rating: h.rating ?? 0,
    price: { amount: h.price?.amount ?? 0 },
    location: h.area ?? undefined,
    description: undefined,
    amenities: h.amenities ?? [],
    distance: undefined,
    phone: undefined,
    email: undefined,
    url: h.url ?? undefined, // pass if available
  }));
}

export default function Planner() {
  const { loading, result, error, submitTrip } = useTrip();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="relative z-10 container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-blue-400 bg-clip-text text-transparent mb-4">
            Trip Planner
          </h1>
          <p className="text-gray-400 text-lg">
            Create unforgettable journeys with AI-powered planning
          </p>
        </div>

        {/* Trip Form */}
        <div className="mb-12">
          <TripForm onSubmit={(payload) => submitTrip(payload, planTrip)} />
        </div>

        {/* Loading */}
        {loading && (
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-12 border border-gray-700/50 shadow-xl text-center">
            <Loader2 className="w-12 h-12 text-blue-400 mx-auto mb-4 animate-spin" />
            <p className="text-xl text-white mb-2">Planning your perfect trip…</p>
            <p className="text-gray-400">This might take a few moments</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-red-900/20 border border-red-500/30 rounded-2xl p-6 mb-8">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-red-400" />
              <p className="text-red-300 font-medium">Something went wrong</p>
            </div>
            <p className="text-red-200 mt-2 ml-9">{error}</p>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-8">
            {/* Budget + Hotels */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <BudgetBar budget={(result as PlanResponse).budget} />
              <MapView hotels={normalizeHotels((result as PlanResponse).hotel_choices)} />
            </div>

            {/* Itinerary */}
            <div>
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">Your Itinerary</h2>
                <p className="text-gray-400">Every moment planned to perfection</p>
              </div>

              <div className="space-y-6">
                {(result as PlanResponse).days.map((d) => (
                  <DayCard key={d.date} day={d} />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
