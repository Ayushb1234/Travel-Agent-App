// src/App.tsx
import React, { useMemo, useState } from "react";
import {
  MapPin, Calendar, Users, DollarSign, Star, Camera, Sun, Moon,
  Navigation, Settings, ChevronDown, Plus, X, Loader2, AlertCircle,
  CheckCircle, TrendingUp, TrendingDown, Coffee,
} from "lucide-react";
import "./styles.css";

/* ===== Types ===== */
type ISODate = string;
type Preferences = {
  stay: { min_rating: number; areas: string[]; ac_required: boolean; refundable: boolean };
  food: { veg_only: boolean; meals_per_day: number };
  pace: "relaxed" | "normal" | "fast";
  must_visit: string[];
  avoid: string[];
};
type TripFormPayload = {
  city: string; start_date: ISODate; end_date: ISODate;
  people: number; budget_total_inr: number; preferences: Preferences;
};
type BudgetSummary = { totals: Record<string, number>; grand_total: number; under_budget_by: number };
type Hotel = { id: number | string; name: string; rating?: number | null; price?: { amount?: number | null }; location?: string };
type PlanItem = { time: string; activity: string; cost_inr: number };
type DayPlan = { date: ISODate; day_cost_total?: number; plan?: PlanItem[] };
type TripResult = { budget: BudgetSummary; hotel_choices: Hotel[]; days: DayPlan[] };

/* ===== API client (real backend) ===== */
async function planTripApi(payload: TripFormPayload): Promise<TripResult> {
  const res = await fetch("/api/plan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Backend ${res.status}`);
  return res.json();
}

/* ===== TripForm (unchanged UX) ===== */
const TripForm: React.FC<{ onSubmit: (p: TripFormPayload) => void }> = ({ onSubmit }) => {
  const [city, setCity] = useState("");
  const [start, setStart] = useState<ISODate>("");
  const [end, setEnd] = useState<ISODate>("");
  const [people, setPeople] = useState(2);
  const [budget, setBudget] = useState(25_000);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [preferences, setPreferences] = useState<Preferences>({
    stay: { min_rating: 3.8, areas: [], ac_required: true, refundable: true },
    food: { veg_only: true, meals_per_day: 2 },
    pace: "relaxed",
    must_visit: [],
    avoid: [],
  });

  const validDates = useMemo(() => {
    if (!start || !end) return false;
    const s = new Date(`${start}T00:00:00`);
    const e = new Date(`${end}T00:00:00`);
    return !isNaN(+s) && !isNaN(+e) && e >= s;
  }, [start, end]);

  const days = useMemo(() => {
    if (!validDates) return 0;
    const s = new Date(`${start}T00:00:00`).getTime();
    const e = new Date(`${end}T00:00:00`).getTime();
    return Math.max(0, Math.ceil((e - s) / 86_400_000));
  }, [validDates, start, end]);

  const budgetPerDay = days > 0 ? Math.round(budget / days) : budget;
  const budgetPerPerson = people > 0 ? Math.round(budget / people) : budget;

  const handleSubmit = () => {
    const cleanCity = city.trim();
    if (!cleanCity) { alert("Please enter a destination city."); return; }
    if (!validDates) { alert("Please choose valid start and end dates."); return; }

    onSubmit({
      city: cleanCity,
      start_date: start,
      end_date: end,
      people: Math.max(1, people),
      budget_total_inr: Math.max(0, budget),
      preferences,
    });
  };

  const [newMustVisit, setNewMustVisit] = useState("");
  const [newAvoid, setNewAvoid] = useState("");
  const addMustVisit = () => { const v = newMustVisit.trim(); if (!v) return; setPreferences(p => ({ ...p, must_visit: [...p.must_visit, v] })); setNewMustVisit(""); };
  const removeMustVisit = (v: string) => setPreferences(p => ({ ...p, must_visit: p.must_visit.filter(x => x !== v) }));
  const addAvoid = () => { const v = newAvoid.trim(); if (!v) return; setPreferences(p => ({ ...p, avoid: [...p.avoid, v] })); setNewAvoid(""); };
  const removeAvoid = (v: string) => setPreferences(p => ({ ...p, avoid: p.avoid.filter(x => x !== v) }));

  return (
    <div className="card elev">
      <div className="row gap-12 align-center mb-24">
        <div className="badge grad-blue"><MapPin size={22} /></div>
        <div>
          <h2 className="h2">Plan Your Perfect Trip</h2>
          <p className="muted">Tell us what you're looking for</p>
        </div>
      </div>

      <div className="stack-24">
        <div className="stack-16">
          <h3 className="h3 row gap-8 align-center"><Calendar size={18} className="text-blue" /> Trip Details</h3>

          <div>
            <label className="label">Destination</label>
            <div className="input-icon">
              <MapPin size={16} className="muted" />
              <input className="input" value={city} onChange={(e) => setCity(e.target.value)} placeholder="Enter destination city" />
            </div>
          </div>

          <div className="grid-2 gap-16">
            <div>
              <label className="label">Start Date</label>
              <input className="input" type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <label className="label">End Date</label>
              <input className="input" type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>

          <div className="grid-2 gap-16">
            <div>
              <label className="label row gap-8 align-center"><Users size={16} /> Number of People</label>
              <input className="input" type="number" min={1} max={20}
                value={people} onChange={(e) => setPeople(Math.max(1, parseInt(e.target.value || "1", 10)))} />
            </div>
            <div>
              <label className="label row gap-8 align-center"><DollarSign size={16} /> Total Budget (₹)</label>
              <input className="input" type="number" min={1000} step={1000}
                value={budget} onChange={(e) => setBudget(Math.max(0, parseInt(e.target.value || "0", 10)))} />
            </div>
          </div>

          {days > 0 && (
            <div className="card soft">
              <div className="grid-3">
                <div className="stat"><div className="stat__value text-blue">{days}</div><div className="stat__label">Days</div></div>
                <div className="stat"><div className="stat__value text-emerald">₹{budgetPerDay.toLocaleString("en-IN")}</div><div className="stat__label">Per Day</div></div>
                <div className="stat"><div className="stat__value text-purple">₹{budgetPerPerson.toLocaleString("en-IN")}</div><div className="stat__label">Per Person</div></div>
              </div>
            </div>
          )}
        </div>

        <button type="button" className="link row gap-8 align-center" onClick={() => setShowAdvanced(s => !s)}>
          <Settings size={16} /><span>Advanced Preferences</span>
          <ChevronDown size={16} className={`chev ${showAdvanced ? "up" : ""}`} />
        </button>

        {showAdvanced && (
          <div className="stack-16">
            <div className="card soft">
              <h4 className="h4 row gap-8 align-center"><Star size={18} className="text-yellow" /> Accommodation</h4>

              <div className="stack-16">
                <div>
                  <label className="label">Minimum Rating: {preferences.stay.min_rating.toFixed(1)}★</label>
                  <input type="range" min="1" max="5" step="0.1"
                    value={preferences.stay.min_rating}
                    onChange={(e) => setPreferences(p => ({ ...p, stay: { ...p.stay, min_rating: parseFloat(e.target.value) } }))} />
                </div>

                <div className="grid-2 gap-16">
                  <label className="checkbox">
                    <input type="checkbox" checked={preferences.stay.ac_required}
                      onChange={(e) => setPreferences(p => ({ ...p, stay: { ...p.stay, ac_required: e.target.checked } }))} />
                    <span>AC Required</span>
                  </label>

                  <label className="checkbox">
                    <input type="checkbox" checked={preferences.stay.refundable}
                      onChange={(e) => setPreferences(p => ({ ...p, stay: { ...p.stay, refundable: e.target.checked } }))} />
                    <span>Refundable Booking</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="card soft">
              <h4 className="h4 row gap-8 align-center"><CheckCircle size={18} className="text-emerald" /> Must Visit Places</h4>

              <div className="row gap-12 mb-12">
                <input className="input grow" placeholder="Add a place you must visit"
                  value={newMustVisit}
                  onChange={(e) => setNewMustVisit(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addMustVisit(); } }} />
                <button type="button" className="btn blue" onClick={addMustVisit}><Plus size={16} /></button>
              </div>

              <div className="chips">
                {preferences.must_visit.map((place, idx) => (
                  <span key={`${place}-${idx}`} className="chip danger">
                    {place}
                    <button type="button" className="chip__close" onClick={() => removeMustVisit(place)}><X size={12} /></button>
                  </span>
                ))}
              </div>

              <div className="mt-16">
                <div className="label">Avoid</div>
                <div className="row gap-12 mb-12">
                  <input className="input grow" placeholder="Add places/areas to avoid"
                    value={newAvoid}
                    onChange={(e) => setNewAvoid(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addAvoid(); } }} />
                  <button type="button" className="btn" onClick={addAvoid}><Plus size={16} /></button>
                </div>
                <div className="chips">
                  {preferences.avoid.map((place, idx) => (
                    <span key={`${place}-${idx}`} className="chip">
                      {place}
                      <button type="button" className="chip__close" onClick={() => removeAvoid(place)}><X size={12} /></button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        <button className="btn primary w-full" onClick={handleSubmit}>
          <MapPin size={18} /> <span>Create My Perfect Trip</span>
        </button>
      </div>
    </div>
  );
};

/* ===== BudgetBar / DayCard / MapView (unchanged) ===== */
const BudgetBar: React.FC<{ budget: BudgetSummary | null | undefined }> = ({ budget }) => {
  if (!budget || !budget.grand_total) return null;
  const status =
    budget.under_budget_by > 0
      ? { icon: CheckCircle, text: "Under Budget", cls: "ok" }
      : budget.under_budget_by === 0
      ? { icon: AlertCircle, text: "At Budget Limit", cls: "warn" }
      : { icon: AlertCircle, text: "Over Budget", cls: "bad" };
  const Icon = status.icon;

  return (
    <div className="card">
      <div className="row between mb-16">
        <div className="row gap-12 align-center">
          <div className="badge grad-emerald"><DollarSign size={20} /></div>
          <h3 className="h3">Budget Breakdown</h3>
        </div>
        <div className={`status ${status.cls}`}><Icon size={16} /> <span>{status.text}</span></div>
      </div>

      <div className="stack-12 mb-16">
        {Object.entries(budget.totals).map(([category, amount]) => {
          const val = Number(amount) || 0;
          const pct = Math.min((val / budget.grand_total) * 100, 100);
          return (
            <div key={category} className="bar">
              <div className="row between mb-8">
                <span className="label cap">{category.replace(/_/g, " ")}</span>
                <span className="strong">₹{val.toLocaleString("en-IN")}</span>
              </div>
              <div className="bar__track"><div className="bar__fill" style={{ width: `${pct}%` }} /></div>
            </div>
          );
        })}
      </div>

      <div className="card soft row between">
        <div>
          <div className="strong">Grand Total</div>
          <div className="h2 m0">₹{budget.grand_total.toLocaleString("en-IN")}</div>
        </div>
        <div className="row gap-8 align-center">
          {budget.under_budget_by > 0 ? <TrendingDown size={16} className="text-emerald" /> : <TrendingUp size={16} className="text-red" />}
          <span className="muted">{budget.under_budget_by > 0 ? "Remaining" : "Over Budget"}</span>
          <span className={`strong ${budget.under_budget_by > 0 ? "text-emerald" : "text-red"}`}>
            ₹{Math.abs(budget.under_budget_by).toLocaleString("en-IN")}
          </span>
        </div>
      </div>
    </div>
  );
};

const DayCard: React.FC<{ day: DayPlan }> = ({ day }) => {
  const d = new Date(`${day.date}T00:00:00`);
  const dayOfWeek = !isNaN(+d) ? d.toLocaleDateString("en-US", { weekday: "long" }) : "";
  const formatted = !isNaN(+d) ? d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : day.date;
  const items = day.plan ?? [];

  const getIcon = (activity: string) => {
    const a = activity.toLowerCase();
    if (a.includes("breakfast") || a.includes("lunch") || a.includes("dinner") || a.includes("food")) return Coffee;
    if (a.includes("sightseeing") || a.includes("visit") || a.includes("tour") || a.includes("photography")) return Camera;
    if (a.includes("morning") || a.includes("sunrise")) return Sun;
    if (a.includes("evening") || a.includes("night") || a.includes("sunset")) return Moon;
    return MapPin;
  };
  const timeClass = (time: string) => {
    const h = parseInt(String(time).split(":")[0], 10);
    if (!Number.isFinite(h)) return "tag";
    if (h < 12) return "tag orange";
    if (h < 17) return "tag blue";
    return "tag purple";
  };

  return (
    <div className="card elev">
      <div className="row between mb-16">
        <div className="row gap-12 align-center">
          <div className="badge grad-blue"><Calendar size={20} /></div>
          <div>
            <div className="h3">{dayOfWeek}</div>
            <div className="muted strong">{formatted}</div>
          </div>
        </div>
        <div className="right">
          <div className="row gap-8 text-emerald align-center"><DollarSign size={16} /><span className="label">Daily Total</span></div>
          <div className="h2 m0">₹{(day.day_cost_total ?? 0).toLocaleString("en-IN")}</div>
        </div>
      </div>

      {items.length ? (
        <div className="timeline">
          {items.map((it, idx) => {
            const Icon = getIcon(it.activity);
            return (
              <div key={`${it.activity}-${it.time}-${idx}`} className="timeline__item">
                <div className="timeline__dot"><Icon size={16} /></div>
                <div className="timeline__card">
                  <div className="row between mb-8">
                    <span className={timeClass(it.time)}>{it.time}</span>
                    <div className="pill money">₹{(it.cost_inr ?? 0).toLocaleString("en-IN")}</div>
                  </div>
                  <div className="strong">{it.activity}</div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="empty">
          <Calendar size={32} className="muted" />
          <p>No activities planned for this day</p>
        </div>
      )}
    </div>
  );
};

const MapView: React.FC<{ hotels: Hotel[] | null | undefined }> = ({ hotels }) => {
  const list = hotels ?? [];
  if (list.length === 0) {
    return (
      <div className="card center">
        <Navigation size={48} className="muted" />
        <h3 className="h3">No Hotels Available</h3>
        <p className="muted">Hotel options will appear here once your trip is planned.</p>
      </div>
    );
  }

  return (
    <div className="card elev">
      <div className="row gap-12 align-center mb-16">
        <div className="badge grad-emerald"><Navigation size={20} /></div>
        <div>
          <div className="h3">Hotel Options & Map</div>
          <div className="muted">{list.length} hotels found</div>
        </div>
      </div>

      <div className="map-placeholder">
        <Navigation size={32} />
        <div className="muted">Interactive Map (Leaflet/Mapbox ready)</div>
      </div>

      <div className="grid-2 gap-16 mt-16">
        {list.map(h => {
          const nightly = Number(h.price?.amount ?? 0);
          const rating = Number(h.rating ?? 0);
          return (
            <div key={h.id ?? h.name} className="card soft">
              <div className="row between align-start">
                <div>
                  <div className="strong">{h.name}</div>
                  <div className="row gap-6 text-yellow align-center"><Star size={14} /><span>({rating.toFixed(1)})</span></div>
                </div>
                <div className="pill">
                  <div className="label muted">Per Night</div>
                  <div className="h4 m0">₹{nightly.toLocaleString("en-IN")}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ===== useTrip (REAL – calls backend) ===== */
function useTrip() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TripResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submitTrip = async (params: TripFormPayload) => {
    try {
      setLoading(true); setResult(null); setError(null);
      const data = await planTripApi(params);
      setResult(data);
    } catch (e: any) {
      setError(e?.message ?? "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return { loading, result, error, submitTrip };
}

/* ===== Small UI bits for landing ===== */
const SiteNav: React.FC<{ onPrimaryClick: () => void; showPlannerCta?: boolean; onHome?: () => void; }> = ({
  onPrimaryClick, showPlannerCta = true, onHome
}) => (
  <header className="nav">
    <div className="row gap-8 align-center">
      <div className="badge grad-blue"><MapPin size={18} /></div>
      <strong>Travel Planner</strong>
    </div>
    <div className="row gap-12 align-center">
      {onHome && <button className="link" onClick={onHome}>Home</button>}
      {showPlannerCta && (
        <button className="btn primary" onClick={onPrimaryClick}>
          <Calendar size={16} /> <span>Start Planning</span>
        </button>
      )}
    </div>
  </header>
);

const FooterAnalytics: React.FC = () => (
  <footer className="container center" style={{ padding: "40px 0 80px" }}>
    <div className="stats">
      <div><div className="stat__value text-blue">1000+</div><div className="muted">Destinations</div></div>
      <div><div className="stat__value text-purple">50K+</div><div className="muted">Happy Travelers</div></div>
      <div><div className="stat__value text-emerald">95%</div><div className="muted">Satisfaction Rate</div></div>
    </div>
  </footer>
);

/* ===== Planner ===== */
const Planner: React.FC<{ onBackHome: () => void }> = ({ onBackHome }) => {
  const { loading, result, error, submitTrip } = useTrip();

  return (
    <>
      <SiteNav onPrimaryClick={onBackHome} showPlannerCta={false} onHome={onBackHome} />
      <main className="container">
        <div className="center mb-24">
          <h1 className="h1 gradient">Plan Your Perfect Trip</h1>
          <p className="muted">Create unforgettable journeys with AI-powered planning</p>
        </div>

        <div className="stack-24">
          <TripForm onSubmit={submitTrip} />

          {loading && (
            <div className="card center">
              <Loader2 className="spin" size={40} />
              <div className="h4">Planning your perfect trip...</div>
              <p className="muted">Analyzing destinations, finding best hotels, and creating your itinerary</p>
            </div>
          )}

          {error && (
            <div className="card error">
              <div className="row gap-8 align-center"><AlertCircle /> <strong>Something went wrong</strong></div>
              <div className="mt-8">{error}</div>
            </div>
          )}

          {result && (
            <div className="stack-24">
              <div className="grid-2 gap-24">
                <BudgetBar budget={result.budget} />
                <MapView hotels={result.hotel_choices} />
              </div>

              <div>
                <div className="center mb-16">
                  <h2 className="h2">Your Personalized Itinerary</h2>
                  <p className="muted">Every moment planned to perfection</p>
                </div>
                <div className="stack-16">
                  {result.days.map((d) => <DayCard key={d.date} day={d} />)}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <FooterAnalytics />
    </>
  );
};

/* ===== App (landing + planner) ===== */
export default function App() {
  const [view, setView] = useState<"landing" | "planner">("landing");

  const LandingPage: React.FC = () => (
    <div className="landing">
      {/* Navbar with logo on the left */}
      <SiteNav onPrimaryClick={() => setView("planner")} />

      {/* Background & hero */}
      <div className="landing__bg" />
      <div className="landing__inner" style={{ alignItems: "flex-start", textAlign: "left" }}>
        <h1 className="display">Multi-Agent<br />Travel Planner</h1>
        <p className="lead" style={{ maxWidth: 720 }}>
          Experience the future of travel planning with AI-powered itineraries,
          smart budget optimization, and personalized recommendations.
        </p>

        <div className="pills">
          <div className="pill"><Calendar size={14} /><span>Smart Scheduling</span></div>
          <div className="pill"><DollarSign size={14} /><span>Budget Optimization</span></div>
          <div className="pill"><Star size={14} /><span>Personalized Picks</span></div>
        </div>

        <button className="btn primary mt-24" onClick={() => setView("planner")}>
          <MapPin size={18} /> <span>Start Planning Your Journey</span>
        </button>
      </div>

      {/* Footer analytics row */}
      <FooterAnalytics />
    </div>
  );

  return view === "landing" ? <LandingPage /> : <Planner onBackHome={() => setView("landing")} />;
}
