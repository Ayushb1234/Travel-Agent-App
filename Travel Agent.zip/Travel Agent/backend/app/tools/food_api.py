# backend/app/tools/food_api.py
from typing import List, Optional
import httpx

from app.core.schemas import VendorOption, Price
from app.core.config import settings  # has OSM_USER_AGENT and DEFAULT_RADIUS_M if you followed earlier step

NOMINATIM = "https://nominatim.openstreetmap.org/search"
OVERPASS = "https://overpass-api.de/api/interpreter"

HEADERS = {"User-Agent": getattr(settings, "OSM_USER_AGENT", "TravelPlanner/1.0")}


async def _geocode_city(city: str) -> Optional[tuple[float, float]]:
    """Geocode city name to (lat, lon) using Nominatim."""
    params = {"q": city, "format": "json", "limit": 1}
    async with httpx.AsyncClient(headers=HEADERS, timeout=20) as client:
        r = await client.get(NOMINATIM, params=params)
        r.raise_for_status()
        data = r.json()
    if not data:
        return None
    return float(data[0]["lat"]), float(data[0]["lon"])


def _overpass_query_food(lat: float, lon: float, radius_m: int, veg_only: bool) -> str:
    """Build an Overpass query for restaurants/cafes/fast_food, optionally vegetarian."""
    veg = '["diet:vegetarian"~"yes|only|strict"]' if veg_only else ""
    # Nodes are plenty for POI search; you can add ways/relations if you want broader coverage.
    return f"""
    [out:json][timeout:25];
    (
      node["amenity"="restaurant"]{veg}(around:{radius_m},{lat},{lon});
      node["amenity"="cafe"]{veg}(around:{radius_m},{lat},{lon});
      node["amenity"="fast_food"]{veg}(around:{radius_m},{lat},{lon});
    );
    out 80;
    """


async def search_food(city: str, veg_only: bool = False, avg_meal_cap: int = 300) -> List[VendorOption]:
    """
    Search food vendors around a city using OpenStreetMap + Overpass.
    Returns VendorOption items similar to the old Google Places version,
    but price is an estimate (capped by avg_meal_cap).
    """
    loc = await _geocode_city(city)
    if not loc:
        return []

    lat, lon = loc
    q = _overpass_query_food(lat, lon, getattr(settings, "DEFAULT_RADIUS_M", 5000), veg_only)

    async with httpx.AsyncClient(headers=HEADERS, timeout=40) as client:
        r = await client.post(OVERPASS, data={"data": q})
        r.raise_for_status()
        data = r.json()

    out: List[VendorOption] = []
    for el in data.get("elements", [])[:60]:
        tags = el.get("tags", {})
        name = tags.get("name") or tags.get("name:en")
        if not name:
            continue

        node_id = el.get("id")
        area = tags.get("addr:suburb") or tags.get("addr:city") or tags.get("addr:district")
        # OSM doesn't provide prices; we just use the provided cap as our best estimate.
        est_meal = max(50, min(avg_meal_cap, avg_meal_cap))  # keep within sane bounds

        out.append(
            VendorOption(
                type="food",
                name=name,
                id=f"osm:{node_id}",
                area=area,
                price=Price(amount=est_meal, unit="per_meal"),
                rating=None,              # OSM has no rating
                reviews_count=None,       # OSM has no review counts
                amenities=[],             # could parse tags for wifi/outdoor_seating etc.
                policies={},              # not available in OSM
                source="osm",
                url=None,                 # you could build OSM permalink if desired
                # Uncomment these two if your schema supports coordinates:
                lat=el.get("lat"),
                lon=el.get("lon"),
            )
        )

    return out
