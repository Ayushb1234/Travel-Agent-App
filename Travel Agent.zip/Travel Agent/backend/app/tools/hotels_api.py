# backend/app/tools/hotels_api.py
from typing import List, Optional
import httpx

from app.core.schemas import VendorOption, Price
from app.core.config import settings  # should expose OSM_USER_AGENT and DEFAULT_RADIUS_M

NOMINATIM = "https://nominatim.openstreetmap.org/search"
OVERPASS = "https://overpass-api.de/api/interpreter"
HEADERS = {"User-Agent": getattr(settings, "OSM_USER_AGENT", "TravelPlanner/1.0")}

# Very rough nightly baselines by city (INR). Tweak as you like.
CITY_BASELINE = {
    "jaipur": 3000,
    "delhi": 4500,
    "new delhi": 4500,
    "mumbai": 5500,
    "pune": 3500,
    "bengaluru": 5000,
    "bangalore": 5000,
    "kolkata": 4200,
    "chennai": 4200,
    "hyderabad": 4500,
}


async def _geocode_city(city: str) -> Optional[tuple[float, float]]:
    """Geocode a city name to (lat, lon) using Nominatim (no key)."""
    params = {"q": city, "format": "json", "limit": 1}
    async with httpx.AsyncClient(headers=HEADERS, timeout=20) as client:
        r = await client.get(NOMINATIM, params=params)
        r.raise_for_status()
        data = r.json()
    if not data:
        return None
    return float(data[0]["lat"]), float(data[0]["lon"])


def _overpass_query_hotels(lat: float, lon: float, radius_m: int) -> str:
    # Hotels & similar: hotel, guest_house, hostel, motel
    return f"""
    [out:json][timeout:25];
    (
      node["tourism"="hotel"](around:{radius_m},{lat},{lon});
      node["tourism"="guest_house"](around:{radius_m},{lat},{lon});
      node["tourism"="hostel"](around:{radius_m},{lat},{lon});
      node["tourism"="motel"](around:{radius_m},{lat},{lon});
      way["tourism"="hotel"](around:{radius_m},{lat},{lon});
      way["tourism"="guest_house"](around:{radius_m},{lat},{lon});
      way["tourism"="hostel"](around:{radius_m},{lat},{lon});
      way["tourism"="motel"](around:{radius_m},{lat},{lon});
    );
    out center 80;
    """


async def search_hotels(city: str, min_rating: float = 3.5, cap_per_night: int = 4000) -> List[VendorOption]:
    """
    Search hotels around a city using OpenStreetMap + Overpass (no billing).
    OSM doesn't provide ratings/prices; we estimate price and omit rating.
    """
    loc = await _geocode_city(city)
    if not loc:
        return []

    lat, lon = loc
    radius = getattr(settings, "DEFAULT_RADIUS_M", 5000)
    q = _overpass_query_hotels(lat, lon, radius)

    async with httpx.AsyncClient(headers=HEADERS, timeout=40) as client:
        r = await client.post(OVERPASS, data={"data": q})
        r.raise_for_status()
        data = r.json()

    base = CITY_BASELINE.get(city.lower(), cap_per_night)
    nightly_est = max(800, min(base, cap_per_night))  # simple clamp

    out: List[VendorOption] = []
    for el in data.get("elements", [])[:60]:
        tags = el.get("tags", {})
        name = tags.get("name") or tags.get("name:en")
        if not name:
            continue

        node_id = el.get("id")
        area = tags.get("addr:suburb") or tags.get("addr:city") or tags.get("addr:district")

        # Extract a best-effort coordinate from node/way(center)
        lat_el = el.get("lat") or (el.get("center") or {}).get("lat")
        lon_el = el.get("lon") or (el.get("center") or {}).get("lon")

        out.append(
            VendorOption(
                type="stay",
                name=name,
                id=f"osm:{node_id}",
                area=area,
                price=Price(amount=nightly_est, unit="per_night",),
                rating=None,            # no rating from OSM
                reviews_count=None,     # no review counts
                amenities=[],           # could parse OSM tags if desired
                policies={},            # not available in OSM
                source="osm",
                url=f"https://www.openstreetmap.org/{el.get('type','node')}/{node_id}",
                # If your schema doesn't have these, remove the next two lines:
                lat=lat_el,
                lon=lon_el,
            )
        )

    # min_rating has no effect with OSM (no ratings). If you want to filter names,
    # you could apply heuristics here, but typically return everything.
    return out
