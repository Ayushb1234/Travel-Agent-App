# backend/app/tools/places_api.py
from typing import List, Optional, Tuple
import re
import httpx

from app.core.schemas import VendorOption, Price
from app.core.config import settings  # expose OSM_USER_AGENT, DEFAULT_RADIUS_M if present

NOMINATIM = "https://nominatim.openstreetmap.org/search"
OVERPASS = "https://overpass-api.de/api/interpreter"
HEADERS = {"User-Agent": getattr(settings, "OSM_USER_AGENT", "TravelPlanner/1.0")}

# A broad set of POI classes for “things to do”
# (tourism=attraction is the catch-all; add/remove as you like)
KIND_FILTERS = [
    ('tourism', 'attraction'),
    ('tourism', 'museum'),
    ('tourism', 'gallery'),
    ('tourism', 'viewpoint'),
    ('tourism', 'zoo'),
    ('tourism', 'theme_park'),
    ('historic', None),           # any historic=*
    ('archaeological_site', None) # historic alternative spelling appears on some data sets
]

def _k2overpass(lat: float, lon: float, radius_m: int) -> str:
    """
    Build an Overpass query that fetches nodes/ways with the above tags.
    We request center coords for ways to get a point to map.
    """
    clauses = []
    for k, v in KIND_FILTERS:
        if v is None:
            # any value for key
            clauses.append(f'node["{k}"](around:{radius_m},{lat},{lon});')
            clauses.append(f'way["{k}"](around:{radius_m},{lat},{lon});')
        else:
            clauses.append(f'node["{k}"="{v}"](around:{radius_m},{lat},{lon});')
            clauses.append(f'way["{k}"="{v}"](around:{radius_m},{lat},{lon});')

    union = "\n      ".join(clauses)
    return f"""
    [out:json][timeout:25];
    (
      {union}
    );
    out center 100;
    """

async def _geocode_city(city: str) -> Optional[Tuple[float, float]]:
    params = {"q": city, "format": "json", "limit": 1}
    async with httpx.AsyncClient(headers=HEADERS, timeout=20) as client:
        r = await client.get(NOMINATIM, params=params)
        r.raise_for_status()
        data = r.json()
    if not data:
        return None
    return float(data[0]["lat"]), float(data[0]["lon"])

def _opening_hours_to_window(oh: str | None) -> dict | None:
    """
    Try to convert a simple opening_hours string into a {open, close} window.
    This is a *best-effort* parse for strings like "09:00-17:30; ..." (first span only).
    If it’s complex (e.g., day ranges), we just return None.
    """
    if not oh:
        return None
    # pick the first HH:MM-HH:MM we see
    m = re.search(r'(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})', oh)
    if not m:
        return None
    open_t, close_t = m.group(1), m.group(2)
    return {"open": open_t, "close": close_t}

async def search_attractions(city: str) -> List[VendorOption]:
    """
    City attractions using OSM Overpass (no API keys).
    Returns mixed POIs (museum, attraction, historic, viewpoint, etc.)
    Price is unknown in OSM → assume 0 (adjust later if you add a pricing source).
    """
    loc = await _geocode_city(city)
    if not loc:
        # minimal fallback so the UI changes with the city
        return [VendorOption(
            type="attraction",
            name=f"{city} City Walk",
            id=f"osm_fallback_{city}",
            price=Price(amount=0, unit="per_entry"),
            duration_min=90,
            area=city,
            source="osm",
        )]

    lat, lon = loc
    radius = getattr(settings, "DEFAULT_RADIUS_M", 5000)
    q = _k2overpass(lat, lon, radius)

    async with httpx.AsyncClient(headers=HEADERS, timeout=40) as client:
        r = await client.post(OVERPASS, data={"data": q})
        r.raise_for_status()
        data = r.json()

    out: List[VendorOption] = []
    for i, el in enumerate(data.get("elements", [])[:60]):
        tags = el.get("tags", {}) or {}
        # Prefer name in local lang, fallback to English
        name = tags.get("name") or tags.get("name:en")
        if not name:
            continue

        eid = el.get("id")
        etype = el.get("type", "node")
        lat_el = el.get("lat") or (el.get("center") or {}).get("lat")
        lon_el = el.get("lon") or (el.get("center") or {}).get("lon")

        # opening hours best-effort
        win = _opening_hours_to_window(tags.get("opening_hours"))

        out.append(
            VendorOption(
                type="attraction",
                name=name,
                id=f"osm:{eid}",
                price=Price(amount=0, unit="per_entry"),  # unknown → assume free (adjust later)
                duration_min=90,                          # default dwell time
                area=tags.get("addr:suburb") or tags.get("addr:city") or tags.get("addr:district") or city,
                time_window=win,
                source="osm",
                url=f"https://www.openstreetmap.org/{etype}/{eid}",
                # remove these two if your schema doesn't have them:
                lat=lat_el,
                lon=lon_el,
            )
        )

    return out
