from pydantic import BaseModel, Field, AwareDatetime
from typing import List, Literal, Optional, Dict

class StayPrefs(BaseModel):
    min_rating: float = 3.5
    areas: List[str] = []
    ac_required: bool = True
    refundable: bool = True

class FoodPrefs(BaseModel):
    veg_only: bool = False
    meals_per_day: int = 2

class Preferences(BaseModel):
    stay: StayPrefs = StayPrefs()
    food: FoodPrefs = FoodPrefs()
    pace: Literal["relaxed","normal","tight"] = "normal"
    must_visit: List[str] = []
    avoid: List[str] = []

class TripRequest(BaseModel):
    city: str
    start_date: str  # "2025-09-12"
    end_date: str    # "2025-09-15"
    people: int = 2
    budget_total_inr: int
    preferences: Preferences = Preferences()

class Price(BaseModel):
    amount: float
    currency: str = "INR"
    unit: Literal["per_night","per_meal","per_entry","total"] = "total"

class VendorOption(BaseModel):
    type: Literal["stay","food","attraction","transport"]
    name: str
    id: str
    url: Optional[str] = None
    area: Optional[str] = None
    price: Price
    rating: Optional[float] = None
    reviews_count: Optional[int] = None
    amenities: List[str] = []
    policies: Dict[str, str] = {}
    time_window: Optional[Dict[str,str]] = None   # {"open":"09:00","close":"17:30"}
    duration_min: Optional[int] = None
    safety_flags: List[str] = []
    source: Optional[str] = None
    last_checked_at: Optional[str] = None

class ItineraryItem(BaseModel):
    time: str
    activity: str
    cost_inr: int
    duration_min: Optional[int] = None

class ItineraryDay(BaseModel):
    date: str
    hotel_id: Optional[str] = None
    plan: List[ItineraryItem] = []
    day_cost_total: int = 0

class BudgetBreakdown(BaseModel):
    totals: Dict[str,int]
    grand_total: int
    under_budget_by: int

class PlanResponse(BaseModel):
    budget: BudgetBreakdown
    hotel_choices: List[VendorOption]
    days: List[ItineraryDay]
