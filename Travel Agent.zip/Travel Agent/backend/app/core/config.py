import os
from pydantic import BaseModel
from dotenv import load_dotenv

# Load .env file
load_dotenv()

class Settings(BaseModel):
    postgres_host: str = os.getenv("POSTGRES_HOST", "localhost")
    postgres_db: str = os.getenv("POSTGRES_DB", "travel")
    postgres_user: str = os.getenv("POSTGRES_USER", "travel")
    postgres_password: str = os.getenv("POSTGRES_PASSWORD", "travel")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    tz: str = os.getenv("TZ", "Asia/Kolkata")
    currency_base: str = os.getenv("CURRENCY_BASE", "INR")

    # 🌍 New: optional MapTiler API key for maps (frontend use)
    maptiler_key: str = os.getenv("MAPTILER_KEY", "")

    # ❌ Removed old keys (Google Places, OpenTripMap)
    # google_places_key: str = os.getenv("GOOGLE_PLACES_KEY", "")
    # opentripmap_key: str = os.getenv("OPENTRIPMAP_KEY", "")

settings = Settings()
