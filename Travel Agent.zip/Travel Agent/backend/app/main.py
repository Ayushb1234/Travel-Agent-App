# backend/app/main.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.schemas import TripRequest, PlanResponse
from app.workflows.graph import plan_trip

# --- Create app ---
app = FastAPI(title="Multi-Agent Travel Planner", version="0.1.0")

# --- CORS (adjust origins to match your frontend) ---
# e.g. Vite default: http://localhost:5173
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        # add your deployed frontend origin(s) here
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Routes ---
@app.get("/")
def root():
    return {
        "service": "Multi-Agent Travel Planner",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health",
        "plan": "/plan",
    }

@app.get("/health")
def health():
    return {
        "ok": True,
        "tz": settings.tz,
        "currency": settings.currency_base,
        # show OSM runtime config bits (informational)
        "osm_user_agent": getattr(settings, "OSM_USER_AGENT", "TravelPlanner/1.0"),
        "radius_m": getattr(settings, "DEFAULT_RADIUS_M", 5000),
    }

@app.post("/plan", response_model=PlanResponse)
async def plan(req: TripRequest):
    try:
        return await plan_trip(req)
    except Exception as e:
        # keep a small, user-safe message in HTTP, log full details in server logs
        # (replace with proper logger if you have one)
        print(f"[ERROR] /plan failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to plan trip")

# --- Optional: quick debug endpoints to verify OSM fetchers ---
# These help you confirm the new no-key tools are working
from app.tools.hotels_api import search_hotels
from app.tools.food_api import search_food
from app.tools.places_api import search_attractions

@app.get("/debug/hotels")
async def debug_hotels(city: str = "Indore"):
    items = await search_hotels(city)
    return {"city": city, "count": len(items), "sample": items[:5]}

@app.get("/debug/food")
async def debug_food(city: str = "Indore", veg_only: bool = False, cap: int = 300):
    items = await search_food(city, veg_only=veg_only, avg_meal_cap=cap)
    return {"city": city, "veg_only": veg_only, "count": len(items), "sample": items[:5]}

@app.get("/debug/attractions")
async def debug_attractions(city: str = "Indore"):
    items = await search_attractions(city)
    return {"city": city, "count": len(items), "sample": items[:5]}
