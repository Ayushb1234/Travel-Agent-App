from app.core.schemas import VendorOption

def normalize_currency(v: VendorOption, target="INR") -> VendorOption:
    # mock: assume already INR
    return v
