from typing import List, Tuple
from app.core.schemas import VendorOption, ItineraryDay, ItineraryItem

def build_itinerary(days: int, people: int, hotel: VendorOption,
                    foods: List[VendorOption], pois: List[VendorOption]) -> List[ItineraryDay]:
    out=[]
    for d in range(days):
        date = f"D{d+1}"
        items=[]
        if foods:
            items.append(ItineraryItem(time="09:00", activity=f"Breakfast at {foods[0].name}",
                                       cost_inr=int(foods[0].price.amount*people)))
        if d < len(pois):
            p = pois[d]
            items.append(ItineraryItem(time="10:30", activity=p.name,
                                       cost_inr=int(p.price.amount*people), duration_min=p.duration_min or 90))
        total = sum(i.cost_inr for i in items)
        out.append(ItineraryDay(date=date, hotel_id=hotel.id if hotel else None, plan=items, day_cost_total=total))
    return out
