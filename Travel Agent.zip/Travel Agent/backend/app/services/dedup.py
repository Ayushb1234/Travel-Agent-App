from typing import List
from app.core.schemas import VendorOption

def dedup(options: List[VendorOption]) -> List[VendorOption]:
    seen = set(); out=[]
    for o in options:
        if o.id in seen: continue
        seen.add(o.id); out.append(o)
    return out
