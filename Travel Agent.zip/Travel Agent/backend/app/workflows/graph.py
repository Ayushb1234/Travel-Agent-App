from app.core.schemas import TripRequest, PlanResponse, BudgetBreakdown
from app.agents.planner import plan_directives
from app.agents import stay as stay_agent, food as food_agent, attractions as poi_agent
from app.services.normalize import normalize_currency
from app.services.dedup import dedup
from app.agents.optimizer import pick_hotel, pick_food
from app.services.itinerary_builder import build_itinerary

async def plan_trip(req: TripRequest) -> PlanResponse:
    directives = plan_directives(req)
    budget = directives["budget"]
    stay_q = directives["stay_query"]; food_q = directives["food_query"]

    hotels = await stay_agent.run(req, **stay_q)
    foods  = await food_agent.run(req, **food_q)
    pois   = await poi_agent.run(req)

    hotels = [normalize_currency(h) for h in hotels]
    foods  = [normalize_currency(f) for f in foods]
    pois   = [normalize_currency(p) for p in pois]

    hotels, foods, pois = dedup(hotels), dedup(foods), dedup(pois)

    hotel = pick_hotel(hotels, budget["stay_cap_per_night"])
    food_choices = pick_food(foods, food_q["avg_meal_cap"])

    days = build_itinerary(budget["days"], req.people, hotel, food_choices, pois)

    stay_total = budget["days"] * int(hotel.price.amount if hotel else 0)
    food_total = sum(d.day_cost_total for d in days)  # includes only breakfast + POI fee mock
    visits_total = sum(int(p.price.amount)*req.people for p in pois[:budget["days"]])
    transport_total = int(0.08 * req.budget_total_inr)  # naive

    grand = stay_total + food_total + transport_total
    under = req.budget_total_inr - grand

    return PlanResponse(
        budget=BudgetBreakdown(
            totals={"stay": stay_total, "food": food_total, "attractions": visits_total,
                    "transport": transport_total, "buffer": max(0, under)},
            grand_total=grand,
            under_budget_by=under
        ),
        hotel_choices=hotels[:3],
        days=days
    )
