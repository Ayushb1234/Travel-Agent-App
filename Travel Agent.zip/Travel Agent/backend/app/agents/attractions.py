from typing import List
from app.core.schemas import TripRequest, VendorOption
from app.tools.places_api import search_attractions

async def run(req: TripRequest) -> List[VendorOption]:
    return await search_attractions(req.city)
