from typing import List
from app.core.schemas import TripRequest, VendorOption
from app.tools.food_api import search_food

async def run(req: TripRequest, veg_only: bool, avg_meal_cap: int) -> List[VendorOption]:
    return await search_food(req.city, veg_only=veg_only, avg_meal_cap=avg_meal_cap)
