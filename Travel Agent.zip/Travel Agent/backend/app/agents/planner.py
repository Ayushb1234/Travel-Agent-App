from app.core.schemas import TripRequest
from app.agents.budget import allocate_budget

def plan_directives(req: TripRequest):
    b = allocate_budget(req)
    return {
        "budget": b,
        "stay_query": {
            "min_rating": req.preferences.stay.min_rating,
            "cap_per_night": b["stay_cap_per_night"]
        },
        "food_query": {
            "veg_only": req.preferences.food.veg_only,
            "avg_meal_cap": req.preferences.food.meals_per_day * (b["food_cap_per_day"] // max(1, req.people))
        }
    }
