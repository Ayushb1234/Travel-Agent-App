from app.core.schemas import VendorOption

def verify_stay(h: VendorOption) -> list[str]:
    issues=[]
    if (h.rating or 0) < 3.5: issues.append("Low rating")
    return issues
