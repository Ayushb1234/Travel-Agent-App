from typing import Protocol, List
from app.core.schemas import TripRequest, VendorOption

class Agent(Protocol):
    async def run(self, req: TripRequest, **kwargs) -> List[VendorOption]: ...
