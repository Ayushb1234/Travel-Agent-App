from app.core.schemas import TripRequest
from math import ceil

def allocate_budget(req: TripRequest):
    D = max(1, _days(req.start_date, req.end_date))
    B = req.budget_total_inr
    # Heuristic split
    stay = int(0.45 * B)
    food = int(0.22 * B)
    visits = int(0.18 * B)
    transport = int(0.08 * B)
    buffer = B - (stay + food + visits + transport)
    return {
        "stay_cap_per_night": ceil(stay / D),
        "food_cap_per_day": ceil(food / (D+1)),
        "visit_cap_total": visits,
        "transport_cap_total": transport,
        "buffer": buffer,
        "days": D
    }

def _days(s, e):
    from datetime import date
    s = date.fromisoformat(s); e = date.fromisoformat(e)
    return (e - s).days
