from typing import List, Tuple
from app.core.schemas import VendorOption

def pick_hotel(hotels: List[VendorOption], cap_per_night: int) -> VendorOption | None:
    hotels = sorted(hotels, key=lambda h: (-1*(h.rating or 0), h.price.amount))
    for h in hotels:
        if h.price.amount <= cap_per_night:
            return h
    return hotels[0] if hotels else None

def pick_food(foods: List[VendorOption], per_meal_cap: int) -> List[VendorOption]:
    foods = [f for f in foods if f.price.amount <= per_meal_cap]
    return sorted(foods, key=lambda f: f.price.amount)[:3] or foods[:3]
