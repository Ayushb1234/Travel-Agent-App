# backend/app/agents/stay.py
from typing import List
from app.core.schemas import TripRequest, VendorOption
from app.tools.hotels_api import search_hotels

async def run(req: TripRequest, min_rating: float, cap_per_night: int) -> List[VendorOption]:
    return await search_hotels(req.city, min_rating=min_rating, cap_per_night=cap_per_night)
